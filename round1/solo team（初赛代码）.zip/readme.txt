﻿团队：solo team
团队成员昵称：三生石gg
联系方式：15735186430

tianchi_ship.ipynb是程序文件。 
变量train_path,test_path是训练、测试数据的路径，请修改为官方的训练数据和测试集B。

result.csv 是最终的提交结果

使用的模型是lightgbm 单模，10折交叉训练。超参数无需修改。

环境： lightgbm==2.3.1 无GPU  pandas==0.24.2，其它包的环境应该不会有兼容型问题
